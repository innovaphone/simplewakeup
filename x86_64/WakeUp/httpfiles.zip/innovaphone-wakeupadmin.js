var Innovaphone = Innovaphone || {};
Innovaphone.WakeUpAdmin = Innovaphone.WakeUpAdmin || function (start, args) {
    this.createNode("body");
    var that = this;

    var colorSchemes = {
        dark: {
            "--bg": "#191919",
            "--bg-config-title": "#333333",
            "--bg-button": "#303030",
            "--text-standard": "#f2f5f6",
            "--text-config-title": "#ffffff",
            "--text-configitem-label": "#ffffff",
            "--text-button": "#ffffff",
            "--border": "#000000",
            "--forms": "#000000",
        },
        light: {
            "--bg": "white",
            "--button": "#e0e0e0",
            "--text-standard": "#4a4a49",
        }
    };
    var schemes = new innovaphone.ui1.CssVariables(colorSchemes, start.scheme);
    start.onschemechanged.attach(function () { schemes.activate(start.scheme) });

    var texts = new innovaphone.lib1.Languages(Innovaphone.WakeUpTexts, start.lang);

    var app = new innovaphone.appwebsocket.Connection(start.url, start.name);
    app.checkBuild = true;
    app.onconnected = app_connected;
    app.onmessage = app_message;

    var configItems;
    function app_connected(domain, user, dn, appdomain) {
        app.send({ api: "admin", mt: "AdminMessage" });
    }

    function app_message(obj) {
        if (obj.api == "admin" && obj.mt == "ConfigItemsResult") {
            configItems = obj.configItems;

            document.getElementById('txtConfigMaster').value = configItems.MasterPbx;
            document.getElementById('txtBaseRequest').value = configItems.BaseRequest;
            document.getElementById('txtSourceName').value = configItems.SourceName;
            document.getElementById('txtSourceNumber').value = configItems.SourceNumber;
            document.getElementById('txtRetry').value = configItems.Retry;
            document.getElementById('txtTimeOut').value = configItems.TimeOut;
            document.getElementById('url').innerHTML = configItems.URL + '/';

            var urls = "<ul>";
            urls += "<li>" + configItems.URL + '/{cn}/config/' + '</li>';
            urls += "<li>" + configItems.URL + '/{cn}/add/{hour}/{min}/{sec}/{name}/{number}/{retry}/{multi}/{timeout}/{fallback}/{bool}/{boolnot}/' + '</li>';
            urls += "<li>" + configItems.URL + '/{cn}/get/' + '</li>';
            urls += "<li>" + configItems.URL + '/{cn}/get/{index}/' + '</li>';
            urls += "<li>" + configItems.URL + '/{cn}/rem/{index}/' + '</li>';
            urls += "</ul>";
            document.getElementById('action_urls').innerHTML = urls;
        }
    }

    var panel = this.add(new innovaphone.ui1.Div(null, null, 'innovaphone-wakeupadmin-panel'));
    init();

    function init() {
        panel.clear();
        console.log('Creating the HTML Framework.');

        var content = panel.add(new innovaphone.ui1.Div(null, null, null).setAttribute('id', 'content'));

        // Config Item - PBX
        content.add(new innovaphone.ui1.Div(null, 'PBX', 'configTitle'));
        var configMasterPbx = content.add(new innovaphone.ui1.Div(null, null, 'configItemBox'));
        configMasterPbx.add(new innovaphone.ui1.Div(null, null, 'configItemLabel')).addTranslation(texts, "configmasterpbx");
        configMasterPbx.add(new innovaphone.ui1.Input(null, null, null, 100, null, 'configItemInput').setAttribute('id', 'txtConfigMaster'));        

        // Config Items - Script Defaults
        content.add(new innovaphone.ui1.Div(null, 'Script defaults', 'configTitle'));
        var configSourceName = content.add(new innovaphone.ui1.Div(null, null, 'configItemBox'));
        configSourceName.add(new innovaphone.ui1.Div(null, null, 'configItemLabel')).addTranslation(texts, "configsourcename");
        configSourceName.add(new innovaphone.ui1.Input(null, null, null, 100, null, 'configItemInput').setAttribute('id', 'txtSourceName'));

        var configSourceNumber = content.add(new innovaphone.ui1.Div(null, null, 'configItemBox'));
        configSourceNumber.add(new innovaphone.ui1.Div(null, null, 'configItemLabel')).addTranslation(texts, "configsourcenumber");
        configSourceNumber.add(new innovaphone.ui1.Input(null, null, null, 100, null, 'configItemInput').setAttribute('id', 'txtSourceNumber'));

        var configRetry = content.add(new innovaphone.ui1.Div(null, null, 'configItemBox'));
        configRetry.add(new innovaphone.ui1.Div(null, null, 'configItemLabel')).addTranslation(texts, "configretry");
        configRetry.add(new innovaphone.ui1.Input(null, null, null, 100, null, 'configItemInput').setAttribute('id', 'txtRetry'));

        var configTimeOut = content.add(new innovaphone.ui1.Div(null, null, 'configItemBox'));
        configTimeOut.add(new innovaphone.ui1.Div(null, null, 'configItemLabel')).addTranslation(texts, "configtimeout");
        configTimeOut.add(new innovaphone.ui1.Input(null, null, null, 100, null, 'configItemInput').setAttribute('id', 'txtTimeOut'));

        // Config Items - Service
        content.add(new innovaphone.ui1.Div(null, 'Service', 'configTitle'));
        var configBaseRequest = content.add(new innovaphone.ui1.Div(null, null, 'configItemBox'));
        configBaseRequest.add(new innovaphone.ui1.Div(null, null, 'configItemLabel')).addTranslation(texts, "configbaserequest");
        configBaseRequest.add(new innovaphone.ui1.Input(null, null, null, 100, null, 'configItemInput').setAttribute('id', 'txtBaseRequest').setAttribute('readonly', 'true'));

        // URL
        content.add(new innovaphone.ui1.Div(null, 'Base URL', 'configTitle'));
        var configURL = content.add(new innovaphone.ui1.Div(null, null, 'configItemBox'));
        configURL.add(new innovaphone.ui1.Div(null, null, 'configItemLabel').setAttribute('id', 'url'));

        // URL
        content.add(new innovaphone.ui1.Div(null, 'Action URLS', 'configTitle'));
        var configURL = content.add(new innovaphone.ui1.Div(null, null, 'configItemBox'));
        configURL.add(new innovaphone.ui1.Div(null, null, 'configItemLabel').setAttribute('id', 'action_urls'));

        // Control Buttons
        var footer = panel.add(new innovaphone.ui1.Div("position:absolute; width:100%; bottom:0px; height:40px"));
        footer.add(new innovaphone.ui1.Div("right:10px; bottom:10px", null, 'configButton')).addTranslation(texts, "ok").addEvent("click", onconfigok).testId("innovaphone-wakeup-ok");
        footer.add(new innovaphone.ui1.Div("right:110px; bottom:10px", null, 'configButton')).addTranslation(texts, "cancel").addEvent("click", onconfigcancel).testId("innovaphone-wakeup-cancel");
    }

    function onconfigok() {
        var configItems = {
            MasterPbx: document.getElementById('txtConfigMaster').value,
            BaseRequest: document.getElementById('txtBaseRequest').value,
            SourceName: document.getElementById('txtSourceName').value,
            SourceNumber: document.getElementById('txtSourceNumber').value,
            Retry: document.getElementById('txtRetry').value,
            TimeOut: document.getElementById('txtTimeOut').value,
        }
        app.send({ api: "admin", mt: "SetConfigItems", configItems: configItems })

        console.log('OK-button clicked');
    }
    function onconfigcancel() {
        console.log('Cancel-button clicked');

        app.send({ api: "admin", mt: "GetConfigItems" });
    }
}

Innovaphone.WakeUpAdmin.prototype = innovaphone.ui1.nodePrototype;
