
var Innovaphone = Innovaphone || {};
Innovaphone.WakeUpTexts = {
    en: {
        ok: "OK",
        cancel: "Cancel",
        configmasterpbx: "Master PBX",
        configbaserequest: "Base Request",
        configsourcename: "Source Name",
        configsourcenumber: "Source Number",
        configretry: "Retries (#)",
        configtimeout: "Timeout (s)",
    },
    de: {
        ok: "OK",
        cancel: "Abbrechen",
        configmasterpbx: "Master PBX",
        configbaserequest: "Base Request",
        configsourcename: "Source Name",
        configsourcenumber: "Source Number",
        configretry: "Retries (#)",
        configtimeout: "Timeout (s)",
    }
}
