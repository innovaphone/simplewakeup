
var innovaphone = innovaphone || {};
innovaphone.wakeupmanagertexts = {
    en: {
        pluginTitle: "WakeUp Service",
        wakeupservice: "WakeUp Service",
        wakeupadmin: "WakeUp Admin",
        title: "Name",
        sip: "SIP",
        url: "URL",
        del: "Delete",
        ok: "OK",
        cancel: "Cancel",
        addapp: "Add app",
        editapp: "Edit the App",
        config: "Configuration",
        configmasterpbx: "Master PBX",
        configrelativeuri: "Relative URI",
    },
    de: {
        pluginTitle: "WakeUp Service",
        wakeupservice: "WakeUp Service",
        wakeupadmin: "WakeUp Admin",
        title: "Name",
        sip: "SIP",
        url: "URL",
        del: "Löschen",
        ok: "OK",
        cancel: "Abbrechen",
        addapp: "App hinzufügen",
        editapp: "App bearbeiten",
        config: "Configuration",
        configmasterpbx: "Master PBX",
        configrelativeuri: "Relative URI",
    }
}
