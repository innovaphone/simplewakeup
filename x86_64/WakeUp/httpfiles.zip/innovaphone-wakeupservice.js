// Global Variables
var baseUrl = WebServer.url;
const actionsArray = ['get', 'add', 'rem', 'config'];
var invalidTimeoutReplace = '25';

// WebServer OnUrlChanged
log("WebServer Url: " + baseUrl + Config.BaseRequest);
WebServer.onurlchanged(function (newUrl) {
    baseUrl = newUrl;
    log("WebServer Url: " + baseUrl + Config.BaseRequest);
});
log("WebServer 'OnUrlChanged'-callback started.");

// Config OnChanged
Config.onchanged(function () {
    log("Config Changed: ");
    log("MasterPBX: " + Config.MasterPbx);
    log("BaseRequest: " + Config.BaseRequest);
    log("SourceName: " + Config.SourceName);
    log("SourceNumber: " + Config.SourceNumber);
    log("Retry: " + Config.Retry);
    log("TimeOut: " + Config.TimeOut);
});
Config.Dummy = 'dummy';
Config.save();


// PbxAdminApi Connection -> WebSever OnRequest
new PbxApi("PbxAdminApi").onconnected(function (conn) {
    log("PbxAdminApi Connected from PBX '" + conn.pbx + "'");

    // Webserver must only be started on connection from MasterPBX
    if (conn.pbx == Config.MasterPbx) {
        WebServer.onrequest(Config.BaseRequest, function (req) {
            // Get information about the request
            var headerUserAgent = req.header("User-Agent");
            var headerHost = req.header("Host");
            var relativeUri = decodeURIComponent(req.relativeUri).replace(/\+/g, ' ');

            log("HTTP-Request->User-Agent: " + headerUserAgent);
            log("HTTP-Request->Host: " + headerHost);
            log("HTTP-Request->Url: " + baseUrl + Config.BaseRequest + relativeUri);

            if (req.method == "GET") {
                // Get the request parameters
                var requestParams = GetRequestParameters(relativeUri);

                // Fire the 'GetObject"-Request; Request-info is available in the src-field
                if (requestParams.userCN && requestParams.action && actionsArray.indexOf(requestParams.action) != -1) {
                    conn.send(JSON.stringify({ api: "PbxAdminApi", mt: "GetObject", src: JSON.stringify(requestParams), cn: requestParams.userCN, template: "with" }));
                } else {
                    req.responseContentType("xml")
                        .sendResponse()
                        .onsend(function (req) {
                            req.send(new TextEncoder("utf-8").encode(CreateResponseError('Invalid Parameters')), true);
                        });
                }
            }
            else {
                // Reject request with 400 'Bad Request'
                req.cancel(500);
            }

            // Process the PbxAdmin-Messages
            conn.onmessage(function (msg) {
                msg = JSON.parse(msg);
                log("PbxAdminApi->Message: " + JSON.stringify(msg));

                // Request-parameters are found in the src-field
                var params = JSON.parse(msg.src);
                log(JSON.stringify(params));

                if (msg.mt === "GetObjectResult") {
                    var objectGuid = 'guid' in msg ? msg.guid : null;
                    var wakeUpNumber = 'wakeups' in msg ? msg.wakeups.length : 0;

                    if (!objectGuid) {
                        req.responseContentType("xml")
                            .sendResponse()
                            .onsend(function (req) {
                                req.send(new TextEncoder("utf-8").encode(CreateResponseError('Unknown Object')), true);
                            });
                    } else {
                        switch (params.action) {
                            case 'get':
                            case 'get_add':
                            case 'get_rem':
                                var index = 'param0' in params ? params.param0 : -1;

                                // get-action without a given index 
                                // or action is get after an 'add' or 'rem' action (update-count)
                                if (index == -1 || params.action == 'get_add' || params.action == 'get_rem') {
                                    log(JSON.stringify(req));
                                    req.responseContentType("xml")
                                        .sendResponse()
                                        .onsend(function (req) {
                                            req.send(new TextEncoder("utf-8").encode(CreateResponseCount(params.userCN, objectGuid, wakeUpNumber)), true);
                                        });
                                }
                                // get-action with a given index
                                else {
                                    // Wrong Index
                                    if (index >= wakeUpNumber) {
                                        req.responseContentType("xml")
                                            .sendResponse()
                                            .onsend(function (req) {
                                                req.send(new TextEncoder("utf-8").encode(CreateResponseError('No valid Index')), true);
                                            });
                                        return;
                                    }

                                    // Good Index
                                    req.responseContentType("xml")
                                        .sendResponse()
                                        .onsend(function (req) {
                                            req.send(new TextEncoder("utf-8").encode(CreateResponseWakeUp(params.userCN, objectGuid, wakeUpNumber, index, msg.wakeups[index])), true);
                                        });
                                }
                                break;
                            case 'rem':
                                var index = 'param0' in params ? params.param0 : -1;

                                // rem-action without a given index
                                if (index == -1 || index >= wakeUpNumber) {
                                    req.responseContentType("xml")
                                        .sendResponse()
                                        .onsend(function (req) {
                                            req.send(new TextEncoder("utf-8").encode(CreateResponseError('No valid Index')), true);
                                        });
                                } else {
                                    // Remove the WakeUp at the given index from the WakeUps
                                    var wakeUpArray = msg.wakeups;
                                    wakeUpArray.splice(index, 1);

                                    // Add guid and numbers of Wakeups to the Params (need for the answer back)
                                    params.objectGuid = objectGuid;
                                    params.wakeUpNumber = wakeUpArray.length;

                                    // Fire UpdateObject -> Fire new GetObject in 'UpdateObjectResult' (further)
                                    conn.send(JSON.stringify({ api: "PbxAdminApi", mt: "UpdateObject", src: JSON.stringify(params), guid: objectGuid, wakeups: wakeUpArray }))
                                }
                                break;
                            case 'add':
                                var newWakeUp = {
                                    "h": params.param0 != null ? params.param0 : '',
                                    "m": params.param1 != null ? params.param1 : '',
                                    "s": params.param2 != null ? params.param2 : ''
                                };

                                // Add addional parameters only if needed
                                if (params.param3 && params.param3 != '0' && params.param3 != '-') {
                                    log("Wake Up Param added (Destination Name): " + params.param3);
                                    newWakeUp["name"] = params.param3;
                                }
                                if (params.param4 && params.param4 != '0' && params.param4 != '-') {
                                    log("Wake Up Param added (Destination Number): " + params.param4);
                                    newWakeUp["num"] = params.param4;
                                }
                                if (params.param5 && params.param5 != '0' && params.param5 != '-') {
                                    log("Wake Up Param added (Retry): " + params.param5);
                                    newWakeUp["retry"] = params.param5;
                                } // Numeric
                                if (params.param6 && params.param6 != '0' && params.param6 != '-') {
                                    log("Wake Up Param added (Multi): " + params.param6);
                                    newWakeUp["multi"] = "true";
                                } // Boolean
                                if (params.param7 && params.param7 != '0' && params.param7 != '-' && Number.isInteger(Number.parseInt(params.param7))) {
                                    log("Wake Up Param added (TimeOut): " + params.param7);
                                    newWakeUp["to"] = params.param7;
                                } else {
                                    log("Wake Up Param added (TimeOut defaulted (invalidTimeoutReplace)): " + invalidTimeoutReplace);
                                    newWakeUp["to"] = invalidTimeoutReplace;
                                }

                                // Numberic
                                if (params.param8 && params.param8 != '0' && params.param8 != '-') {
                                    log("Wake Up Param added (Fallback): " + params.param8);
                                    newWakeUp["fallback"] = params.param10;
                                }
                                if (params.param9 && params.param9 != '0' && params.param9 != '-') {
                                    log("Wake Up Param added (Bool): " + params.param9);
                                    newWakeUp["bool"] = params.param9;
                                }
                                if (params.param10 && params.param10 != '0' && params.param10 != '-') {
                                    log("Wake Up Param added (Bool-Not): " + params.param10);
                                    newWakeUp["bool-not"] = "true";
                                }

                                log("Check Add New WakeUp: " + JSON.stringify(newWakeUp));

                                // Add the new WakeUp to the existing WakeUps
                                var wakeUpArray = msg.wakeups;
                                wakeUpArray.push(newWakeUp);

                                // Add guid and numbers of Wakeups to the Params (need for the answer back)
                                params.objectGuid = objectGuid;
                                params.wakeUpNumber = wakeUpArray.length;

                                // Fire UpdateObject -> Send Answer 'UpdateObjectResult' (below)
                                params.wakeUpNumber = wakeUpArray.length;
                                conn.send(JSON.stringify({ api: "PbxAdminApi", mt: "UpdateObject", src: JSON.stringify(params), guid: objectGuid, wakeups: wakeUpArray }));
                                break;
                            case 'config':
                                req.responseContentType("xml")
                                    .sendResponse()
                                    .onsend(function (req) {
                                        req.send(new TextEncoder("utf-8").encode(CreateResponseConfig()), true);
                                    });
                                break;
                        }
                    }
                }
                else if (msg.mt == 'UpdateObjectResult') {
                    // adjust the action 
                    params.action = 'get_' + params.action;

                    conn.send(JSON.stringify({ api: "PbxAdminApi", mt: "GetObject", src: JSON.stringify(params), cn: requestParams.userCN, template: "with" }));

                }
            });
        }/*, function (auth) {
        if (auth.user == httpLogin) auth.password(httpPassword);
        else auth.reject();
    }*/);
        log("WebServer 'OnRequest'-callback started.");
    }

    conn.onclose(function () {
        log("PbxAdminApi Disconnected.");
    });
});

function GetRequestParameters(uri) {
    var uriParameters = uri.split('/');                                     // Split all parameters into an array
    uriParameters.shift();                                                  // Remove the first empty parameter
    log('HTTP-Request->Uri Parameters: ' + JSON.stringify(uriParameters));

    var requestParameters = {};
    // userCN and action are fixed parameters
    requestParameters.userCN = uriParameters.length > 0 ? decodeURI(uriParameters[0]) : null;
    requestParameters.action = uriParameters.length > 1 ? decodeURI(uriParameters[1]) : null;

    // Other parameters are variable parameters
    if (uriParameters.length > 2 && uriParameters[2]) requestParameters.param0 = decodeURI(uriParameters[2]);
    if (uriParameters.length > 3 && uriParameters[3]) requestParameters.param1 = decodeURI(uriParameters[3]);
    if (uriParameters.length > 4 && uriParameters[4]) requestParameters.param2 = decodeURI(uriParameters[4]);
    if (uriParameters.length > 5 && uriParameters[5]) requestParameters.param3 = decodeURI(uriParameters[5]);
    if (uriParameters.length > 6 && uriParameters[6]) requestParameters.param4 = decodeURI(uriParameters[6]);
    if (uriParameters.length > 7 && uriParameters[7]) requestParameters.param5 = decodeURI(uriParameters[7]);
    if (uriParameters.length > 8 && uriParameters[8]) requestParameters.param6 = decodeURI(uriParameters[8]);
    if (uriParameters.length > 9 && uriParameters[9]) requestParameters.param7 = decodeURI(uriParameters[9]);
    if (uriParameters.length > 10 && uriParameters[10]) requestParameters.param8 = decodeURI(uriParameters[10]);
    if (uriParameters.length > 11 && uriParameters[11]) requestParameters.param9 = decodeURI(uriParameters[11]);
    if (uriParameters.length > 12 && uriParameters[12]) requestParameters.param10 = decodeURI(uriParameters[12]);
    log('HTTP-Request->Parameters: ' + JSON.stringify(requestParameters));

    return requestParameters;
}
function CreateResponseError(error) {
    // Response-Template
    var response = '<?xml version=\"1.0\" encoding=\"utf-8\"?> \
<voicemail xmlns=\"http://www.innovaphone.com/xsd/voicemail6.xsd\"> \
<assign out=\"$error\" value=\"{error}\" /> \
</voicemail>';

    // Replacements
    response = response.replace('{error}', error);

    log("HTTP-Response (Error): " + response);
    return response;
}
function CreateResponseCount(cn, guid, count) {
    // Response-Template
    var response = '<?xml version=\"1.0\" encoding=\"utf-8\"?> \
<voicemail xmlns=\"http://www.innovaphone.com/xsd/voicemail6.xsd\"> \
<assign out=\"$cn\" value=\"{cn}\" /> \
<assign out=\"$guid\" value=\"{guid}\" /> \
<assign out=\"$count\" value=\"{count}\" /> \
</voicemail>';

    // Replacements
    response = response.replace('{cn}', cn)
        .replace('{guid}', guid)
        .replace('{count}', count);

    log("HTTP-Response (Count): " + response);
    return response;
}
function CreateResponseConfig() {
    // Response-Template
    var response = '<?xml version=\"1.0\" encoding=\"utf-8\"?> \
<voicemail xmlns=\"http://www.innovaphone.com/xsd/voicemail6.xsd\"> \
<assign out=\"$appDestinationName\" value=\"{name}\" /> \
<assign out=\"$appDestinationNumber\" value=\"{number}\" /> \
<assign out=\"$appRetry\" value=\"{retry}\" /> \
<assign out=\"$appTimeout\" value=\"{timeout}\" /> \
</voicemail>';

    // Replacements
    response = response.replace('{name}', Config.SourceName)
        .replace('{number}', Config.SourceNumber)
        .replace('{retry}', Config.Retry)
        .replace('{timeout}', Config.TimeOut);

    log("HTTP-Response (Count): " + response);
    return response;
}
function CreateResponseWakeUp(cn, guid, count, index, wakeup) {
    // Response-Template
    var response = '<?xml version="1.0" encoding="utf-8"?> \
<voicemail xmlns="http://www.innovaphone.com/xsd/voicemail6.xsd"> \
<assign out="$cn" value="{cn}" /> \
<assign out="$guid" value="{guid}" /> \
<assign out="$index" value="{index}" /> \
<assign out="$count" value="{count}" /> \
<assign out="$hour" value="{hour}" /> \
<assign out="$min" value="{min}" /> \
<assign out="$sec" value="{sec}" /> \
<assign out="$name" value="{name}" /> \
<assign out="$num" value="{num}" /> \
<assign out="$retry" value="{retry}" /> \
<assign out="$multi" value="{multi}" /> \
<assign out="$to" value="{to}" /> \
<assign out="$fallback" value="{fallback}" /> \
<assign out="$bool" value="{bool}" /> \
<assign out="$bool-not" value="{bool-not}" /> \
</voicemail>';

    // Replacements
    response = response.replace('{cn}', cn)
        .replace('{guid}', guid)
        .replace('{count}', count)
        .replace('{index}', index)
        .replace('{hour}', 'h' in wakeup ? wakeup["h"] : "")
        .replace('{min}', 'm' in wakeup ? wakeup["m"] : "")
        .replace('{sec}', 's' in wakeup ? wakeup["s"] : "")
        .replace('{name}', 'name' in wakeup ? wakeup["name"] : "")
        .replace('{num}', 'num' in wakeup ? wakeup["num"] : "")
        .replace('{retry}', 'retry' in wakeup ? wakeup["retry"] : "")
        .replace('{multi}', 'mult' in wakeup ? wakeup["mult"] : "")
        .replace('{to}', 'to' in wakeup ? wakeup["to"] : "")
        .replace('{fallback}', 'fallback' in wakeup ? wakeup["falback"] : "")
        .replace('{bool}', 'bool' in wakeup ? wakeup["bool"] : "")
        .replace('{bool-not}', 'bool-not' in wakeup ? wakeup["bool-not"] : "");

    log("HTTP-Response (WakeUp): " + response);
    return response;
}

// User-App connection
new JsonApi("user").onconnected(function(conn) {
    if (conn.app == "innovaphone-wakeup") {
        conn.onmessage(function(msg) {
            var obj = JSON.parse(msg);
            if (obj.mt == "UserMessage") {
                conn.send(JSON.stringify({ api: "user", mt: "UserMessageResult", src: obj.src }));
            }
        });
    }
});

// Admin-App connection
new JsonApi("admin").onconnected(function(conn) {
    if (conn.app == "innovaphone-wakeupadmin") {
        conn.onmessage(function(msg) {
            var obj = JSON.parse(msg);

            var configItems = {
                URL: baseUrl + Config.BaseRequest,
                MasterPbx: Config.MasterPbx,
                BaseRequest: Config.BaseRequest,
                SourceName: Config.SourceName,
                SourceNumber: Config.SourceNumber,
                Retry: Config.Retry,
                TimeOut: Config.TimeOut,
            }

            if (obj.mt == "AdminMessage") {
                conn.send(JSON.stringify({ api: "admin", mt: "ConfigItemsResult", configItems: configItems, src: obj.src }));
            }
            if (obj.mt == "GetConfigItems") {
                conn.send(JSON.stringify({ api: "admin", mt: "ConfigItemsResult", configItems: configItems, src: obj.src }));
            }
            if (obj.mt == "SetConfigItems") {
                if (obj.configItems && obj.configItems.MasterPbx) {
                    Config.MasterPbx = obj.configItems.MasterPbx;
                }
                if (obj.configItems && obj.configItems.BaseRequest) {
                    Config.BaseRequest = obj.configItems.BaseRequest;
                }
                if (obj.configItems) {
                    Config.SourceName = obj.configItems.SourceName;
                    Config.SourceNumber = obj.configItems.SourceNumber;
                    Config.Retry = obj.configItems.Retry;
                    Config.TimeOut = obj.configItems.TimeOut;
                }

                Config.save();
            }
        });
    }
});


